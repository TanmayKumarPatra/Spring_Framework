/**
 * 
 */
package com.user.service;

import java.util.HashSet;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.userlogin.dao.IUserDetailsDao;

/**
 * @author 416747
 *
 */
@Service
public class UserDetailsValidationServiceImpl implements UserDetailsService  {
	
	@Autowired
	private IUserDetailsDao userDetailsDao;

	public UserDetails loadUserByUsername(String username)
			throws UsernameNotFoundException, DataAccessException {
		com.user.domain.UserDetails userDetails = getUserDetailsDao().findOne(username);
		Set<GrantedAuthority> grantedAuthorities = new HashSet<>();
		grantedAuthorities.add(new SimpleGrantedAuthority(userDetails.getUserType()));
		
		// TODO Auto-generated method stub
		return new User(username, userDetails.getPassword(), grantedAuthorities);
	}

	/**
	 * @return the userDetailsDao
	 */
	public IUserDetailsDao getUserDetailsDao() {
		return userDetailsDao;
	}

	/**
	 * @param userDetailsDao the userDetailsDao to set
	 */
	public void setUserDetailsDao(IUserDetailsDao userDetailsDao) {
		this.userDetailsDao = userDetailsDao;
	}

}
