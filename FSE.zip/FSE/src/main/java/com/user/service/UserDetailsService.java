/**
 * 
 */
package com.user.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.user.business.UserDetailsBusiness;

/**
 * @author Kamal Krishna
 *
 */
@Service
public class UserDetailsService {

	@Autowired
	private UserDetailsBusiness userDetailsBusiness;
	
	

	/**
	 * @return the userDetailsBusiness
	 */
	public UserDetailsBusiness getUserDetailsBusiness() {
		return userDetailsBusiness;
	}

	/**
	 * @param userDetailsBusiness the userDetailsBusiness to set
	 */
	public void setUserDetailsBusiness(UserDetailsBusiness userDetailsBusiness) {
		this.userDetailsBusiness = userDetailsBusiness;
	}
}
