/**
 * 
 */
package com.user.to;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;


/**
 * @author 416747
 *
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class UserTo {

	@JsonProperty("name")
	private String name;

	@JsonProperty("email")
	private String email;

	@JsonProperty("username")
	private String username;

	@JsonProperty("password")
	private String password;
	
	private String captchaEntered;
	private String captchaAnswer;

	/**
	 * @return the name
	 */
	@JsonProperty("name")
	public String getName() {
		return name;
	}

	/**
	 * @param name the name to set
	 */
	@JsonProperty("name")
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * @return the email
	 */
	@JsonProperty("email")
	public String getEmail() {
		return email;
	}

	/**
	 * @param email the email to set
	 */
	@JsonProperty("email")
	public void setEmail(String email) {
		this.email = email;
	}

	/**
	 * @return the username
	 */
	@JsonProperty("username")
	public String getUsername() {
		return username;
	}

	/**
	 * @param username the username to set
	 */
	@JsonProperty("username")
	public void setUsername(String username) {
		this.username = username;
	}

	/**
	 * @return the password
	 */
	@JsonProperty("password")
	public String getPassword() {
		return password;
	}

	/**
	 * @param password the password to set
	 */
	@JsonProperty("password")
	public void setPassword(String password) {
		this.password = password;
	}

	/**
	 * @return the captchaEntered
	 */
	public String getCaptchaEntered() {
		return captchaEntered;
	}

	/**
	 * @param captchaEntered the captchaEntered to set
	 */
	public void setCaptchaEntered(String captchaEntered) {
		this.captchaEntered = captchaEntered;
	}

	/**
	 * @return the captchaAnswer
	 */
	public String getCaptchaAnswer() {
		return captchaAnswer;
	}

	/**
	 * @param captchaAnswer the captchaAnswer to set
	 */
	public void setCaptchaAnswer(String captchaAnswer) {
		this.captchaAnswer = captchaAnswer;
	}
}
