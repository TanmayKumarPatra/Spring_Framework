/**
 * 
 */
package com.user.business;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.user.domain.UserDetails;
import com.user.to.UserTo;
import com.userlogin.dao.IUserDetailsDao;

/**
 * @author Kamal Krishna
 *
 */
@Component
public class UserDetailsBusiness {

	@Autowired
	private IUserDetailsDao userDetailsDao;
	
	

	/**
	 * @return the userDetailsDao
	 */
	public IUserDetailsDao getUserDetailsDao() {
		return userDetailsDao;
	}

	/**
	 * @param userDetailsDao the userDetailsDao to set
	 */
	public void setUserDetailsDao(IUserDetailsDao userDetailsDao) {
		this.userDetailsDao = userDetailsDao;
	}
}
