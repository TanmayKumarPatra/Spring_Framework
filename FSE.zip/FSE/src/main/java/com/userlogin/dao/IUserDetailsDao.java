/**
 * 
 */
package com.userlogin.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.user.domain.UserDetails;

@Repository
public interface IUserDetailsDao extends JpaRepository<UserDetails, String> {
	
	/*@Query(value="select userdetails from UserDetails userdetails where userdetails.username = :username")
	public UserDetails getUserDetialsForUserName(@Param("username")String userName);*/

}
