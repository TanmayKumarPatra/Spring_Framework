/**
 * 
 */
package com.userlogin.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * @author 416747
 *
 */
public class SampleHttpServlet extends HttpServlet{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public void init(){
		System.out.println("Servlet Initialised");
	}
	
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException{
		
		request.getRequestDispatcher("/WEB-INF/views/home.jsp").forward(request, response);
	}
	
	 public void destroy() {
	      System.out.println("Servlet Destroyed");
	}
}
