/**
 * 
 */
package com.userlogin.controller;

import java.io.ByteArrayOutputStream;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.xml.bind.DatatypeConverter;

import nl.captcha.Captcha;
import nl.captcha.text.producer.DefaultTextProducer;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.http.HttpStatus;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.servlet.ModelAndView;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.user.domain.UserDetails;
import com.user.service.UserDetailsService;
import com.user.service.UserDetailsValidationServiceImpl;
import com.user.to.UserTo;
import com.userlogin.dao.IUserDetailsDao;

/**
 * @author 416747
 *
 */
@Controller
@Scope("session")
public class UserHomeController {
	
	@Autowired
	private IUserDetailsDao userDetailsDao;
	
	@Autowired
	private UserDetailsService userDetailsService;
	
	@Autowired
	private UserDetailsValidationServiceImpl userDetailsServiceImpl;
	
	@Autowired
    private AuthenticationManager authenticationManager;

	
	@RequestMapping(value="/login", method = {RequestMethod.GET,
			RequestMethod.POST})
	@ResponseStatus(HttpStatus.OK)
	public ModelAndView login(Model model, String error) 
			throws JsonParseException, JsonMappingException, IOException{
		ModelAndView mv =  new ModelAndView();
		model.addAttribute("user", new UserTo());
		mv.getModel().put("user", new UserTo());
		
		Captcha c = new Captcha.Builder(120, 50).addText(new DefaultTextProducer()).build();
		ByteArrayOutputStream outPutStream = new ByteArrayOutputStream();
		ImageIO.write(c.getImage(), "png", outPutStream);
		model.addAttribute("captcha", DatatypeConverter.printBase64Binary(outPutStream.toByteArray()));
		model.addAttribute("captchaAnswer", c.getAnswer());
		
		if(error!=null){
			model.addAttribute("error", "Your username and password is invalid.");
		}
		return mv;
	}
	
	
	@RequestMapping(value="/register", method = RequestMethod.GET)
	@ResponseStatus(HttpStatus.OK)
	public ModelAndView register(Model model,@RequestParam(value="Error", required = false) String error) throws IOException{
		ModelAndView userDetailsMv = new ModelAndView();
		userDetailsMv.getModel().put("user", new UserTo());
		
		if(null != error){
			model.addAttribute("Error", error);
		}
		
		Captcha c = new Captcha.Builder(120, 50).addText(new DefaultTextProducer()).build();
		ByteArrayOutputStream outPutStream = new ByteArrayOutputStream();
		ImageIO.write(c.getImage(), "png", outPutStream);
		model.addAttribute("captcha", DatatypeConverter.printBase64Binary(outPutStream.toByteArray()));
		model.addAttribute("captchaAnswer", c.getAnswer());
		
		return userDetailsMv;
	}
	
	@RequestMapping(value="/registerUser", method = RequestMethod.POST)
	@ResponseStatus(HttpStatus.OK)
	public ModelAndView registerUser(@ModelAttribute("user") UserTo userDetails, HttpServletRequest requet, HttpServletResponse response){
		ModelAndView userDetailsMv = new ModelAndView("redirect:"+"/update");
		UserDetails userFromDb = getUserDetailsDao().findOne(userDetails.getUsername());
		if(null != userFromDb){
			userDetailsMv = new ModelAndView("redirect:"+"/register");
			userDetailsMv.getModel().put("Error", "UserName Exists");
		}else{
			UserDetails userDetailsDTO = new UserDetails();
			userDetailsDTO.setName(userDetails.getName());
			userDetailsDTO.setEmail(userDetails.getEmail());
			userDetailsDTO.setPassword(userDetails.getPassword());
			userDetailsDTO.setUsername(userDetails.getUsername());
			userDetailsDTO.setUserType("ROLE_USER");
			getUserDetailsDao().save(userDetailsDTO);
		
		
		
			org.springframework.security.core.userdetails.UserDetails userDetailsAfterLogin = userDetailsServiceImpl.loadUserByUsername(userDetails.getUsername());
	        UsernamePasswordAuthenticationToken usernamePasswordAuthenticationToken = new UsernamePasswordAuthenticationToken
	        		(userDetailsAfterLogin, userDetails.getPassword(), userDetailsAfterLogin.getAuthorities());
	
	       Authentication authentication = authenticationManager.authenticate(usernamePasswordAuthenticationToken);
	        SecurityContextHolder.getContext().setAuthentication(authentication);
		}
		return userDetailsMv;
	}
	
	@RequestMapping(value="/update", method = {RequestMethod.GET,RequestMethod.POST})
	@ResponseStatus(HttpStatus.OK)
	public ModelAndView updateUser(Model model,@RequestParam(value="Error", required = false) String error, 
			@RequestParam(value="Success", required = false) String success) throws IOException{
		ModelAndView userDetailsMv = new ModelAndView();
		userDetailsMv.getModel().put("user", new UserTo());
		if(null != error){
			model.addAttribute("Error", error);
		}
		if(null != success){
			model.addAttribute("Success", success);
		}
		Captcha c = new Captcha.Builder(120, 50).addText(new DefaultTextProducer()).build();
		ByteArrayOutputStream outPutStream = new ByteArrayOutputStream();
		ImageIO.write(c.getImage(), "png", outPutStream);
		model.addAttribute("captcha", DatatypeConverter.printBase64Binary(outPutStream.toByteArray()));
		model.addAttribute("captchaAnswer", c.getAnswer());
		return userDetailsMv;
	}
	
	@RequestMapping(value="/tutorials", method = {RequestMethod.GET})
	@ResponseStatus(HttpStatus.OK)
	public ModelAndView tutorials(Model model) throws IOException{
		ModelAndView userDetailsMv = new ModelAndView();
		
		return userDetailsMv;
	}
	
	@RequestMapping(value="/admin", method = {RequestMethod.GET})
	@ResponseStatus(HttpStatus.OK)
	public ModelAndView admin(Model model) throws IOException{
		ModelAndView userDetailsMv = new ModelAndView();
		
		return userDetailsMv;
	}
	
	@RequestMapping(value="/accessDenied", method = {RequestMethod.GET})
	@ResponseStatus(HttpStatus.OK)
	public ModelAndView accessDenied(Model model) throws IOException{
		ModelAndView userDetailsMv = new ModelAndView();
		
		return userDetailsMv;
	}
	
	
	@RequestMapping(value="/updateUser", method = RequestMethod.POST)
	@ResponseStatus(HttpStatus.OK)
	public ModelAndView updateUser(Model model, HttpServletRequest requet, HttpServletResponse response, 
			@ModelAttribute("user") UserTo userDetails){
		
		ModelAndView userDetailsMv = new ModelAndView("redirect:"+"/update");
		UserDetails userFromDb = getUserDetailsDao().findOne(userDetails.getUsername());
		if(null == userFromDb){
			model.addAttribute("Error", "UserName Not Exists");
		}else{
			model.addAttribute("Success", "Updated Sucessfully");
			UserDetails userDetailsDTO = new UserDetails();
			userDetailsDTO.setName(userDetails.getName());
			userDetailsDTO.setEmail(userDetails.getEmail());
			userDetailsDTO.setPassword(userDetails.getPassword());
			userDetailsDTO.setUsername(userDetails.getUsername());
			userDetailsDTO.setUserType("ROLE_USER");
			getUserDetailsDao().save(userDetailsDTO);
		}
		
		//userDetailsMv.setViewName("update");
		return userDetailsMv;
	}
	
	/**
	 * @return the userDetailsDao
	 */
	public IUserDetailsDao getUserDetailsDao() {
		return userDetailsDao;
	}

	/**
	 * @param userDetailsDao the userDetailsDao to set
	 */
	public void setUserDetailsDao(IUserDetailsDao userDetailsDao) {
		this.userDetailsDao = userDetailsDao;
	}

	/**
	 * @return the userDetailsService
	 */
	public UserDetailsService getUserDetailsService() {
		return userDetailsService;
	}

	/**
	 * @param userDetailsService the userDetailsService to set
	 */
	public void setUserDetailsService(UserDetailsService userDetailsService) {
		this.userDetailsService = userDetailsService;
	}
}
