/**
 * 
 */


function validateCaptcha(captchaAnswer){
	console.log(captchaAnswer);
	if(captchaAnswer != ($("#captchaEntered").val())){
		$("#invalidCaptcha").css("display","block")
		return false;
	}
	
}